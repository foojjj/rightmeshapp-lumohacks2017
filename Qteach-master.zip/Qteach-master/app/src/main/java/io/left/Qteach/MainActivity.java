package io.left.Qteach;

import android.app.Activity;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashSet;

import io.left.rightmesh.android.AndroidMeshManager;
import io.left.rightmesh.android.MeshService;
import io.left.rightmesh.id.MeshID;
import io.left.rightmesh.mesh.MeshManager;
import io.left.rightmesh.mesh.MeshStateListener;
import io.left.rightmesh.util.MeshUtility;
import io.left.rightmesh.util.RightMeshException;
import io.reactivex.functions.Consumer;

import static io.left.rightmesh.mesh.MeshManager.DATA_RECEIVED;
import static io.left.rightmesh.mesh.MeshManager.PEER_CHANGED;
import static io.left.rightmesh.mesh.MeshManager.REMOVED;
import static java.lang.Integer.parseInt;

public class MainActivity extends Activity implements MeshStateListener {
    // Port to bind app to.
    private static final int QUESTIONNAIRE_PORT = 9876;
    private int viewID = 0;
    // MeshManager instance - interface to the mesh network.
    AndroidMeshManager mm = null;

    // Set to keep track of peers connected to the mesh.
    HashSet<MeshID> users = new HashSet<>();

    /**
     * Called when app first opens, initializes {@link AndroidMeshManager} reference (which will
     * start the {@link MeshService} if it isn't already running.
     *
     * @param savedInstanceState passed from operating system
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mm = AndroidMeshManager.getInstance(MainActivity.this, MainActivity.this);
        Spinner spinner = (Spinner) findViewById(R.id.questionnaire);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.questions_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        RadioButton rb;
        rb = (RadioButton) findViewById(R.id.nameyes);
        rb.setChecked(true);
        rb = (RadioButton) findViewById(R.id.ageyes);
        rb.setChecked(true);
        rb = (RadioButton) findViewById(R.id.genderyes);
        rb.setChecked(true);
        rb = (RadioButton) findViewById(R.id.idyes);
        rb.setChecked(true);
    }

    /**
     * Called when activity is on screen.
     */
    @Override
    protected void onResume() {
        try {
            super.onResume();
            mm.resume();
        } catch (MeshService.ServiceDisconnectedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Called when the app is being closed (not just navigated away from). Shuts down
     * the {@link AndroidMeshManager} instance.
     */
    @Override
    protected void onDestroy() {
        try {
            super.onDestroy();
            mm.stop();
        } catch (MeshService.ServiceDisconnectedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Called by the {@link MeshService} when the mesh state changes. Initializes mesh connection
     * on first call.
     *
     * @param uuid our own user id on first detecting
     * @param state state which indicates SUCCESS or an error code
     */
    @Override
    public void meshStateChanged(MeshID uuid, int state) {
        if (state == MeshStateListener.SUCCESS) {
            try {
                // Binds this app to MESH_PORT.
                // This app will now receive all events generated on that port.
                mm.bind(QUESTIONNAIRE_PORT);

                // Subscribes handlers to receive events from the mesh.
                mm.on(DATA_RECEIVED, new Consumer() {
                    @Override
                    public void accept(Object o) throws Exception {
                        handleDataReceived((MeshManager.RightMeshEvent) o);
                    }
                });
                mm.on(PEER_CHANGED, new Consumer() {
                    @Override
                    public void accept(Object o) throws Exception {
                        handlePeerChanged((MeshManager.RightMeshEvent) o);
                    }
                });

                // If you are using Java 8 or a lambda backport like RetroLambda, you can use
                // a more concise syntax, like the following:
                // mm.on(PEER_CHANGED, this::handlePeerChanged);
                // mm.on(DATA_RECEIVED, this::dataReceived);

                // Enable buttons now that mesh is connected.
                Button btnConfigure = (Button) findViewById(R.id.btnConfigure);
                Button btnSend = (Button) findViewById(R.id.sendQuestionnaire);
                btnConfigure.setEnabled(true);
                btnSend.setEnabled(true);
            } catch (RightMeshException e) {
                String status = "Error initializing the library" + e.toString();
                Toast.makeText(getApplicationContext(), status, Toast.LENGTH_SHORT).show();
                TextView txtStatus = (TextView) findViewById(R.id.txtStatus);
                txtStatus.setText(status);
                return;
            }
        }

        // Update display on successful calls (i.e. not FAILURE or DISABLED).
        if (state == MeshStateListener.SUCCESS || state == MeshStateListener.RESUME) {
            updateStatus();
        }
    }

    /**
     * Update the {@link TextView} with a list of all peers.
     */
    private void updateStatus() {
        String status = "uuid: " + mm.getUuid().toString() + "\npeers:\n";
        for (MeshID user : users) {
            status += user.toString() + "\n";
        }
        TextView txtStatus = (TextView) findViewById(R.id.txtStatus);
        txtStatus.setText(status);
    }

    /**
     * Handles incoming data events from the mesh - toasts the contents of the data.
     *
     * @param e event object from mesh
     */

    /**
    private void handleDataReceived(MeshManager.RightMeshEvent e) {
        final MeshManager.DataReceivedEvent event = (MeshManager.DataReceivedEvent) e;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // Toast data contents.
                String message = new String(event.data);
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();

                // Play a notification.
                Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                Ringtone r = RingtoneManager.getRingtone(MainActivity.this, notification);
                r.play();
            }
        });
    }
     */
    private void handleDataReceived(MeshManager.RightMeshEvent e) {
        final MeshManager.DataReceivedEvent event = (MeshManager.DataReceivedEvent) e;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String result = new String(event.data);
                //Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                if(result.contains(",")){
                    displayResult(result);
                }


                // Play a notification.
                Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                Ringtone r = RingtoneManager.getRingtone(MainActivity.this, notification);
                r.play();
            }
        });
    }
    public void displayResult(String result){
        Toast.makeText(MainActivity.this, result, Toast.LENGTH_SHORT).show();
        final TextView test = (TextView)findViewById(R.id.txtResult);
        test.setText(result);
        View hide = findViewById(R.id.txtStatus);
        hide.setVisibility(View.GONE);
        //String[] parseSub = parseSubmission(result);
        //Takes the score value from string
        // Choose color for text
        /*
        String textViewStr = "";
        for(int i = 0; i < parseSub.length; i++){
            if(i == 0){
                textViewStr = parseSub[i];
            }
            else{
                textViewStr = ", " + parseSub[i];
            }
        }
        */
        //Toast.makeText(MainActivity.this, parseSub.length, Toast.LENGTH_SHORT).show();

        //int score = Integer.parseInt(parseSub[parseSub.length-1]);


        //textView.setText("test");
        /*
        if(score < 5) {
            textView.setTextColor(Color.GREEN);
        }else if(score < 10) {
            textView.setTextColor(Color.CYAN);
        }else if(score < 15) {
            textView.setTextColor(Color.YELLOW);
        }else if(score < 20) {
            textView.setTextColor(Color.parseColor("#FFA500"));
        }else {
            textView.setTextColor(Color.RED);
        }
    */


    }

    /**
     * Handles peer update events from the mesh - maintains a list of peers and updates the display.
     *
     * @param e event object from mesh
     */
    private void handlePeerChanged(MeshManager.RightMeshEvent e) {
        // Update peer list.
        MeshManager.PeerChangedEvent event = (MeshManager.PeerChangedEvent) e;
        if (event.state != REMOVED && !users.contains(event.peerUuid)) {
            users.add(event.peerUuid);
        } else if (event.state == REMOVED){
            users.remove(event.peerUuid);
        }

        // Update display.
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                updateStatus();
            }
        });
    }

    /**
     * Sends "hello" to all known peers.
     *
     * @param v calling view
     */
    /**
    public void sendHello(View v) throws RightMeshException {
     for(MeshID receiver : users) {
     String msg = "Hello to: " + receiver + " from" + mm.getUuid();
     MeshUtility.Log(this.getClass().getCanonicalName(), "MSG: " + msg);
     byte[] testData = msg.getBytes();
     mm.sendDataReliable(receiver, HELLO_PORT, testData);
     }
     }
     */
    public void sendQuestionnaire(View v) throws RightMeshException {
        for(MeshID receiver : users) {
            String msg = "";
            RadioButton rb;
            rb = (RadioButton) findViewById(R.id.nameyes);
            if(rb.isChecked()){
                msg = msg + "?";
            }
            rb = (RadioButton) findViewById(R.id.ageyes);
            if(rb.isChecked()){
                msg = msg + "*";
            }
            rb = (RadioButton) findViewById(R.id.genderyes);
            if(rb.isChecked()){
                msg = msg + "+";
            }
            rb = (RadioButton) findViewById(R.id.idyes);
            if(rb.isChecked()){
                msg = msg + "-";
            }
            Spinner sp = (Spinner) findViewById(R.id.questionnaire);
            msg = msg + sp.getSelectedItemPosition();
            //MeshUtility.Log(this.getClass().getCanonicalName(), "MSG: " + msg);
            byte[] testData = msg.getBytes();
            mm.sendDataReliable(receiver, QUESTIONNAIRE_PORT, testData);
        }
    }
    /**
     * Open mesh settings screen.
     *
     * @param v calling view
     */
    public void configure(View v)
    {
        try {
            mm.showSettingsActivity();
        } catch(RightMeshException ex) {
            MeshUtility.Log(this.getClass().getCanonicalName(), "Service not connected");
        }
    }

    public void onRadioButtonClickedName(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()) {
            case R.id.nameno:
                if (checked)
                    //show question
                    break;
            case R.id.nameyes:
                if (checked)
                    // don't show it
                    break;
        }
    }
    public void onRadioButtonClickedAge(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()) {
            case R.id.ageno:
                if (checked)
                    //show question
                    break;
            case R.id.ageyes:
                if (checked)
                    // don't show it
                    break;
        }
    }
    public void onRadioButtonClickedGender(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()) {
            case R.id.genderno:
                if (checked)
                    //show question
                    break;
            case R.id.genderyes:
                if (checked)
                    // don't show it
                    break;
        }
    }
    public void onRadioButtonClickedID(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()) {
            case R.id.idno:
                if (checked)
                    //show question
                    break;
            case R.id.idyes:
                if (checked)
                    // don't show it
                    break;
        }
    }

    // string will be in format name,age,gender,student_id,questionnaire_id,questionnaire_points
    public String[] parseSubmission(String submission){
        String[] submissionArr = submission.split(",");
        /*if(submissionArr[submissionArr.length-2] == "0"){
            submissionArr[submissionArr.length-2] = "PHQ9";
        }*/
        return submissionArr;
    }

}


